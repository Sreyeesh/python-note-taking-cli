import os
import pytest
from app.note_app import NoteApp

@pytest.fixture
def app():
    """Fixture for NoteApp with a temporary storage file."""
    storage_file = "test_notes.json"
    app_instance = NoteApp(storage_file=storage_file, use_memory=False)
    yield app_instance
    if os.path.exists(storage_file):
        os.remove(storage_file)

def test_add_note_success(app):
    """Test adding a note successfully."""
    result = app.add_note("Test Title", "Test Content", "Test Category", ["tag1", "tag2"])
    assert len(app.notes) == 1
    assert app.notes[0]["title"] == "Test Title"
    assert app.notes[0]["tags"] == ["tag1", "tag2"]
    assert result == "Note added: Test Title - Test Content (Category: Test Category, Tags: tag1, tag2)"

def test_add_note_duplicate(app):
    """Test adding a duplicate note raises an error."""
    app.add_note("Test Title", "Test Content")
    with pytest.raises(ValueError) as excinfo:
        app.add_note("Test Title", "Another Content")
    assert str(excinfo.value) == "A note with the title 'Test Title' already exists."

def test_delete_note_success(app):
    """Test deleting a note successfully."""
    app.add_note("Test Title", "Test Content")
    result = app.delete_note("Test Title")
    assert len(app.notes) == 0
    assert result == "Note with title 'Test Title' has been deleted."

def test_delete_note_not_found(app):
    """Test deleting a note that does not exist."""
    result = app.delete_note("Nonexistent Note")
    assert result == "Note with title 'Nonexistent Note' not found."

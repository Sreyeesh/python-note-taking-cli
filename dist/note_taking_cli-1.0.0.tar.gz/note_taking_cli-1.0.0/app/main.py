from cli import cli  # Import 'cli' from the same folder

if __name__ == "__main__":
    cli()
